/**
 * @file   index.tsx
 * @brief  Intial component for the react app
 * @date   Feb , 2020
 * @author ZCO Engineer
 * @copyright (c) 2024, ZCO
 */
import "bootstrap/dist/css/bootstrap.min.css"
import * as React from 'react';
import * as ReactDOM from 'react-dom';
import { AppContainer } from "react-hot-loader";
import  Layout from "./containers/Layout";
import './index.css';
const settingsData = {
  "activity": {
      "id": "3cj0ccsm78k1j1xg0rnr",
      "spec": "lamp.memory_game",
      "name": "memory",
      "description": "",
      "photo": null,
      "streak": {
          "streak": true,
          "streakTitle": "",
          "streakDesc": ""
      },
      "visualSettings": null,
      "showFeed": true,
      "schedule": [],
      "settings": {
        "delayBeforeRecall" : 60,
        "numberOfTrials" : 3,        
        "imageExposureTime" : 2000
      },
      "category": [
          "assess"
      ]
  },
  "configuration": {
      "language": "en-US"
  },
  "autoCorrect": true,
  "noBack": false
}

// const eventMethod = !!window.addEventListener ? "addEventListener" : "attachEvent"
// const eventer = window[eventMethod]
// const messageEvent = eventMethod === "attachEvent" ? "onmessage" : "message"
// eventer(
//     messageEvent, (e : any) => {    
		ReactDOM.render(
      <AppContainer>
        <Layout 
        data={settingsData}
          />
      </AppContainer>, 		  
		  document.getElementById("root")
		);
//     },
//     false
// )

