// Data.js 

import image1a from "../components/images/Image1a.jpg"
import image1b from "../components/images/Image1b.jpg"
import image1c from "../components/images/Image1c.jpg"
import image1d from "../components/images/Image1d.jpg"
import image1e from "../components/images/Image1e.png"

import image2a from "../components/images/Image2a.jpg"
import image2b from "../components/images/Image2b.jpg"
import image2c from "../components/images/Image2c.jpg"
import image2d from "../components/images/Image2d.jpg"
import image2e from "../components/images/Image2e.png"


import image3a from "../components/images/Image3a.jpg"
import image3b from "../components/images/Image3b.jpg"
import image3c from "../components/images/Image3c.jpg"
import image3d from "../components/images/Image3d.jpg"
import image3e from "../components/images/Image3e.png"

import image4a from "../components/images/Image4a.jpg"
import image4b from "../components/images/Image4b.jpg"
import image4c from "../components/images/Image4c.jpg"
import image4d from "../components/images/Image4d.jpg"
import image4e from "../components/images/Image4e.png"

import image5a from "../components/images/Image5a.jpg"
import image5b from "../components/images/Image5b.jpg"
import image5c from "../components/images/Image5c.jpg"
import image5d from "../components/images/Image5d.jpg"
import image5e from "../components/images/Image5e.png"

import image6a from "../components/images/Image6a.jpg"
import image6b from "../components/images/Image6b.jpg"
import image6c from "../components/images/Image6c.jpg"
import image6d from "../components/images/Image6d.jpg"
import image6e from "../components/images/Image6e.png"


const Data = [ 
	{ 
		id: 0, 
		images: ["french horn", 'rubber ducky'],
		img:image1a, 
		matched: false, 
		option : [image1a, image1b, image1c, image1d],
		missingImg : image1e,
		missingItem : "rubber ducky"
	}, 
	{ 
		id: 1, 
		images: ["pocket knife", 'umbrella'],
		img: image2a, 
		matched: false, 
		option : [image2a, image2b, image2c, image2d],
		missingImg : image2e,
		missingItem : "umbrella"
	}, 
	{ 
		id: 2, 
		images:["fish bowl", 'owl'],
		img:image3a, 
		matched: false, 
		option : [image3a, image3b, image3c, image3d],
		missingImg : image3e,
		missingItem : "owl"
	}, 
	{ 
		id: 3, 
		images: ["dog", 'net'],
		img:image4a, 
		matched: false, 
		option : [image4a, image4b, image4c, image4d],
		missingImg : image4e,
		missingItem : "dog"
	}, 
	{ 
		id: 4, 
		images: ["tennis racket", 'tennis ball'],
		img: image5a, 
		matched: false, 
		option : [image5a, image5b, image5c, image5d],
		missingImg : image5e,
		missingItem : "tennis ball"
	}, 
	{ 
		id: 5, 
		images: ["basket", 'hanger'],
		img: image6a, 
		matched: false, 
		option : [image6a, image6b, image6c, image6d],
		missingImg : image6e,
		missingItem : "hanger"
	}
]; 
export default Data;
