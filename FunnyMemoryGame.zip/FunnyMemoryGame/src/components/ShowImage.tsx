/**
 * @file   src\components\ShowImage.tsx
 * @brief  Show image component for funny memory game
 * @date   Oct , 2024
 * @author ZCO Engineer
 * @copyright (c) 2024, ZCO
 */
import React from "react";

const ShowImage = ({...props}) =>{
    const {image, text} = props;
    return(
        <div className="box-game mt-30">
          <p>{text}</p>
          <img className="imgOption" src={image}></img>
        </div>
    )

}

export default ShowImage