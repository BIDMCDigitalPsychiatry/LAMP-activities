/**
 * @file   src\components\FinalRecognitionPhase.tsx
 * @brief  final recognition phase component for funny memory game
 * @date   Oct , 2024
 * @author ZCO Engineer
 * @copyright (c) 2024, ZCO
 */
import React from "react";
import i18n from "src/i18n";

const FinalRecognitionPhase = ({ ...props }) => {
  const { images, handleImageSelection } = props;
  i18n.changeLanguage(!props.language ? "en-US" : props.language);
  return (
    <div className="box-game mt-30">
      <p>{i18n.t("RECOGNITION4_TEXT")}</p>
      <div className="img-wrap-main">
      <div id="img-wrapper">
        {images && images.length > 0 ? (
          images.map((img: string | undefined) => {
            return (
              <div
                onClick={() => {
                  handleImageSelection(img);
                }}
              >
                <img src={img} />
              </div>
            );
          })
        ) : (
          <></>
        )}
      </div>
      </div>
    </div>
  );
};
export default FinalRecognitionPhase;
